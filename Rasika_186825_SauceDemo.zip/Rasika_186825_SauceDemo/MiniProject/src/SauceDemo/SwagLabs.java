package SauceDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SwagLabs {

	@FindBy(id = "user-name")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement pwd;

	@FindBy(className = "btn_action")
	private WebElement inbtn;

	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")
	private WebElement Backpack;

	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[2]/div[3]/button")
	private WebElement BikeLight;

	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[3]/div[3]/button")
	private WebElement BoltTShirt;

	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[4]/div[3]/button")
	private WebElement FleeceJacket;

	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[5]/div[3]/button")
	private WebElement Onesie;

	@FindBy(linkText = "Test.allTheThings() T-Shirt (Red)")
	private WebElement TShirtRed;

	@FindBy(xpath = "//*[@id=\"inventory_item_container\"]/div/div/div/button")
	private WebElement TShirtaddtocart;

	@FindBy(className = "inventory_details_back_button")
	private WebElement Back;

	@FindBy(xpath = "//*[@id=\"inventory_container\"]/div/div[2]/div[3]/button")
	private WebElement removeHome;

	@FindBy(css = "#shopping_cart_container > a > svg > path")
	private WebElement cartpage;

	@FindBy(xpath = "//*[@id=\"cart_contents_container\"]/div/div[1]/div[6]/div[2]/div[2]/button")
	private WebElement remove6;

	@FindBy(xpath = "//*[@id=\"cart_contents_container\"]/div/div[1]/div[4]/div[2]/div[2]/button")
	private WebElement remove4;

	@FindBy(xpath = "//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/button")
	private WebElement remove3;

	@FindBy(css = "#cart_contents_container > div > div.cart_footer > a.btn_secondary")
	private WebElement cont;

	@FindBy(linkText = "CHECKOUT")
	private WebElement checkout;

	@FindBy(id = "first-name")
	private WebElement uname;

	@FindBy(id = "last-name")
	private WebElement lname;

	@FindBy(id = "postal-code")
	private WebElement pcode;
	
	@FindBy(xpath="//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")
	private WebElement contchk;
	
	@FindBy(linkText="FINISH")
	private WebElement finish;
	
	@FindBy(xpath="//*[@id=\"menu_button_container\"]/div/div[3]/div/button")
	private WebElement scrollbar;
	
	@FindBy(xpath="//*[@id=\"inventory_sidebar_link\"]")
	private WebElement items;
	
	WebDriver driver;

	public SwagLabs(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void stdUser() throws InterruptedException {
		username.sendKeys("standard_user");
		Thread.sleep(1000);
	}

	public void prbUser() throws InterruptedException {
		username.sendKeys("problem_user");
		Thread.sleep(1000);
	}

	public void prfmUser() throws InterruptedException {
		username.sendKeys("performance_glitch_user");
		// Thread.sleep(1000);
	}

	public void pass() throws InterruptedException {
		pwd.sendKeys("secret_sauce");
		Thread.sleep(1000);
	}

	public void loginBtn() throws InterruptedException {
		inbtn.click();
		Thread.sleep(1000);
	}

	public void std() throws InterruptedException {

		// Add in cart in home page
		Backpack.click();
		Thread.sleep(1000);
		BikeLight.click();
		Thread.sleep(1000);
		BoltTShirt.click();
		Thread.sleep(1000);
		FleeceJacket.click();
		Thread.sleep(1000);
		Onesie.click();
		Thread.sleep(1000);
		TShirtRed.click();
		Thread.sleep(1000);

		TShirtaddtocart.click(); // via link
		Thread.sleep(1000);

		Back.click(); // back button
		Thread.sleep(1000);

		removeHome.click(); // remove from home page
		Thread.sleep(1000);

		cartpage.click(); // cart page
		Thread.sleep(1000);

		// remove from cart page
		remove6.click();
		Thread.sleep(1000);
		remove4.click();
		Thread.sleep(1000);
		remove3.click();
		Thread.sleep(1000);
		cont.click(); // continue shopping
		Thread.sleep(1000);

		BoltTShirt.click(); // again adding item
		Thread.sleep(1000);
		cartpage.click();
		Thread.sleep(1000);

		checkout.click(); // checkout button in cart page
		Thread.sleep(1000);
	}

	public void checkoutInfo() throws InterruptedException {
		uname.sendKeys("Sonu");
		lname.sendKeys("Roa");
		pcode.sendKeys("421682");
		Thread.sleep(1000);
		
		contchk.click();
		Thread.sleep(1000);
		
		finish.click();
		Thread.sleep(1000);
		
		scrollbar.click();
		Thread.sleep(2000);
		items.click();
	}
}
