package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pom {
	
	@FindBy(id="user-name")
	private WebElement uname;
	
	@FindBy(id="password")
	private WebElement psswd;
	
	@FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/input[3]")
	private WebElement button;
	
	WebDriver driver;

	public pom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void standard()	
	{
		uname.sendKeys("standard_user");
	}
	public void problem()
	{
		uname.sendKeys("problem_user");
	}
	public void performance()
	{
		uname.sendKeys("performance_glitch_user");
	}
	public void psswd()
	{
		psswd.sendKeys("secret_sauce");
	}
	public void button()
	{
		button.click();
	}

}
