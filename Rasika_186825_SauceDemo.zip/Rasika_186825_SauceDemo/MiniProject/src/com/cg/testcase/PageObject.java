package com.cg.testcase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import SauceDemo.SwagLabs;

public class PageObject {

	WebDriver driver;
	SwagLabs s;
	
	@BeforeMethod
	public void launch() {
		System.setProperty("webdriver.chrome.driver", "C:\\Rasika\\VnV\\Module 3\\Java Workspace\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		s = new SwagLabs(driver);
	}

	@Test
	public void standard() throws InterruptedException {
		s.stdUser();
		s.pass();
		s.loginBtn();
		s.std();
		s.checkoutInfo();
	}

	@Test
	public void problem() throws InterruptedException {
		s.prbUser();
		s.pass();
		s.loginBtn();
	}

	@Test
	public void performance() throws InterruptedException {
		s.prfmUser();
		s.pass();
		s.loginBtn();
		
	}
}

