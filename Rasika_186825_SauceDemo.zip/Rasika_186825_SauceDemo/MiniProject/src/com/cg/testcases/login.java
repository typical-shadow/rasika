package com.cg.testcases;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cg.pageobject.*;
import com.cg.utilities.*;
public class login {

	WebDriver driver;
	DesiredCapabilities d;
	pom p;
	@BeforeMethod
	public void browser() throws IOException
	{
		d=DesiredCapabilities.chrome();		
		/*d.setBrowserName("chrome");
		d.setVersion(" 76.0.3809.100");
		d.setPlatform(Platform.ANY);*/
		driver=new RemoteWebDriver(new URL("http://localhost:4433/wd/hub"), d);
		driver.get(propRead.getprop("url"));
		p=new pom(driver);
	}
	@Test
	public void standarduser()
	{
		p.standard();
		p.psswd();
		p.button();
		
	}
	@Test
	public void problemuser()
	{
		p.problem();
		p.psswd();
		p.button();
	}
	@Test
	public void performanceuser()
	{
		p.performance();
		p.psswd();
		p.button();
	}
	
}
