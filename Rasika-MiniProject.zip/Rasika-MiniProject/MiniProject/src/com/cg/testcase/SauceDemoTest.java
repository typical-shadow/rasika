package com.cg.testcase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Saucedemo.SwagLabs;

public class SauceDemoTest {

	WebDriver driver;
	SwagLabs s;
	
	@BeforeMethod
	public void launch() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.navigate().to("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		s = new SwagLabs(driver);
	}

	@Test
	public void standard() throws InterruptedException {
		s.verifyLogin();
		s.stdUser();
		s.pass();
		s.loginBtn();
		s.std();
		s.checkoutInfo();
	}

	@Test
	public void problem() throws InterruptedException {
		s.verifyLogin();
		s.prbUser();
		s.pass();
		s.loginBtn();
		s.prblm();
		s.checkoutInfo();
	}

	@Test
	public void performance() throws InterruptedException {
		s.verifyLogin();
		s.prfmUser();
		s.pass();
		s.loginBtn();
		s.prfm();
		s.checkoutInfo();
	}
	
	@Test
	public void lock() throws InterruptedException {
		s.verifyLogin();
		s.lockUser();
		s.pass();
		s.loginBtn();
	}
}

